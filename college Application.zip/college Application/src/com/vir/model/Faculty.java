package com.vir.model;

public class Faculty {
	
	private int fid;
	private String fname;
	private int phoneno;

}
